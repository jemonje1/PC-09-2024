﻿using System;
using System.Security.Cryptography.X509Certificates;
using System.Timers;
//Javier Monje Programa Semana 10//
namespace Semana10
{
    public class Semana10
    {
         public static int Main(string [] args)
        {
            Console.WriteLine("Ingrese un número entero positivo");
            int n = int.Parse(Console.ReadLine());
            if (n==0)
            {
                Console.WriteLine($"El factorial del número {n} es 1");
                return 1;
            }
            else
            {
                int factorial = 1;
                for (int i = 1; i <= n; i++)
                {
                    factorial*=i;
                }
                Console.WriteLine($"el factorial del número {n} es {factorial}");
                return factorial;
            }
        }

    }
}